package com.pred.prey;
/**
 * Contains the main method. Controls the various components of the program.
 * 
 * @author Put your name here if you worked on this class
 * @version 1.2, October, 31th 2011
 */
public class PredPrey {
	private static double[][] diffCo;
	private static double[] diffusionRate;
	private static double step;
	private static int noAnimals;
	private static Animal[] animals;
	private static String fileName;
	private static InOut io;
	private static GridAlg grid;
	private static Output output;
	private static double t = 500;

	/**
	 * Controls the IO and Algorithm classes.
	 * 
	 * @param args
	 *            Program does not take command line arguments
	 */
	public static void run(double[] parameters, String fileNameIn)  throws Exception
	{
		try
		{
		noAnimals = 2;

		diffCo = new double[2][2];
		diffusionRate = new double[2];

		diffCo[0][0] = parameters[0];
		diffCo[0][1] = parameters[1];
		diffusionRate[0] = parameters[2];
		diffCo[1][0] = parameters[3];
		diffCo[1][1] = parameters[4];
		diffusionRate[1] = parameters[5];
		step = parameters[6];
		fileName = fileNameIn;

		createAnimals();
		createGrid();
		createOutput();

		System.out.println("Simulating populations...");

		int stepnum = 0;
		int T = 20;
		String colour;

		for (double i = 0; i < t; i += step) {
			if ((stepnum % T == 0) || (stepnum == 0)) {
				for (int k = 0; k < animals.length; k++) {
					if (k == 0) {
						colour = "black&white";
					} else {
						colour = "black&white";
					}

					output.printMeanDensity(
							"./outputs/Mean" + animals[k].getName()
									+ "Densities", animals[k].getDensities(), i);
					output.printPpm("./outputs/" + animals[k].getName()
							+ stepnum + ".ppm", animals[k].getDensities(),
							colour);
				}

			}

			grid.syncUpdate();
			stepnum += 1;

		}

		System.out.println("done");
		}
		catch (Exception e)
		{
		}
	}
	public static void run(double[] parameters, String fileNameIn, double[] parRange, int indicator)  throws Exception
	{
		try
		{
		noAnimals = 2;

		diffCo = new double[2][2];
		diffusionRate = new double[2];

		
		fileName = fileNameIn;

		createAnimals();
		createGrid();
		createOutput();

		System.out.println("Simulating populations...");

		int stepnum = 0;
		int T = 20;
		String colour;
	
	for (int l=0; l<parRange.length; l++)
	{
		parameters[indicator] = parRange[l];
		diffCo[0][0] = parameters[0];
		diffCo[0][1] = parameters[1];
		diffusionRate[0] = parameters[2];
		diffCo[1][0] = parameters[3];
		diffCo[1][1] = parameters[4];
		diffusionRate[1] = parameters[5];
		step = parameters[6];
		for (double i = 0; i < t; i += step) {
			if ((stepnum % T == 0) || (stepnum == 0)) {
				for (int k = 0; k < animals.length; k++) {
					if (k == 0) {
						colour = "black&white";
					} else {
						colour = "black&white";
					}

					output.printMeanDensity(
							"./outputs"+(l+1)+"/Mean" + animals[k].getName()
									+ "Densities", animals[k].getDensities(), i);
					output.printPpm("./outputs"+(l+1)+"/" + animals[k].getName()
							+ stepnum + ".ppm", animals[k].getDensities(),
							colour);
				}

			}

			grid.syncUpdate();
			stepnum += 1;

		}

		System.out.println("done");
		}
	}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("Oops! Something's gone horribly wrong...");
		}
	}

	/**
	 * Takes the values from the gui and sets them to the main program
	 * 
	 * @param gui
	 *            the gui for the program
	 */

	public Animal[] getAnimals() {
		return animals;
	}

	public void setAnimals(Animal[] animals) {
		this.animals = animals;
	}

	/**
	 * Creates the animals as specified by the gui
	 */
	public static void createAnimals() {
		Animal[] theseAnimals = new Animal[noAnimals];

		for (int i = 0; i < noAnimals; i++) {
			theseAnimals[i] = new Animal(noAnimals);
			theseAnimals[i].setDiffCo(diffCo[i]);
			theseAnimals[i].setDiffusionRate(diffusionRate[i]);
		}

		theseAnimals[0].setName("Hare");
		theseAnimals[1].setName("Puma");

		animals = theseAnimals;
	}

	public static void createGrid() {
		io = new InOut(fileName);
		int[][] neighbours = io.getNeighbours();
		grid = new GridAlg(neighbours, animals);
		grid.setStep(step);
	}

	public static void createOutput() {
		output = new Output();
	}
}
