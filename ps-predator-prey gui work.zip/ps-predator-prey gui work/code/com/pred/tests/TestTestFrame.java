package com.pred.tests;
import com.pred.prey.*;
import org.junit.Test;

import junit.framework.TestCase;

/**
 * Junit test class for TestFrame.java
 * 
 * @author Jorge
 *
 * @version 1.0, October, 30th 2011
 */
public class TestTestFrame extends TestCase {
//	TestFrame tf = new TestFrame();
	
	@Test
	public void testParameters() {
/*		assertNotNull(tf.getParameters());
		assertEquals(3.0, tf.getParameters()[0]);
		assertEquals(7.0, tf.getParameters()[1]);
		assertEquals(7.0, tf.getParameters()[4]);
		assertEquals(3.0, tf.getParameters()[6]);*/
	}
}

